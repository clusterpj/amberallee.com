export default function AdminBooksPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Book Management</h1>
      <p>Placeholder for book management interface</p>
    </div>
  )
}
