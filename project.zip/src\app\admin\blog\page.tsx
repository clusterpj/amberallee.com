export default function AdminBlogPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Blog Post Management</h1>
      <p>Placeholder for blog post management interface</p>
    </div>
  )
}
